import { t as e } from "./src-_qSScO88.js";
export default e();