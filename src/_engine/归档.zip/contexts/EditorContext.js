import { E as Y, o as X } from "../vendor-Cr1JWW-B.js";

export const lr = {
  useThumbnail: true,
  lodLevel: 0,
  viewportMoving: false,
  nodeCount: 0,
  handleFollowLimit: 60,
  edgeFxLimit: 100
};

export const ur = Y.createContext(lr.useThumbnail);

export const dr = Y.createContext({
  lodLevel: lr.lodLevel,
  viewportMoving: lr.viewportMoving,
  nodeCount: lr.nodeCount,
  handleFollowLimit: lr.handleFollowLimit,
  edgeFxLimit: lr.edgeFxLimit
});

export function fr({
  value: e,
  children: t
}) {
  let n = e.lodLevel ?? lr.lodLevel,
    r = e.viewportMoving ?? lr.viewportMoving,
    i = e.nodeCount ?? lr.nodeCount,
    a = e.handleFollowLimit ?? lr.handleFollowLimit,
    o = e.edgeFxLimit ?? lr.edgeFxLimit,
    s = Y.useMemo(() => ({
      lodLevel: n,
      viewportMoving: r,
      nodeCount: i,
      handleFollowLimit: a,
      edgeFxLimit: o
    }), [n, r, i, a, o]);
  return X.jsx(ur.Provider, {
    value: e.useThumbnail,
    children: X.jsx(dr.Provider, {
      value: s,
      children: t
    })
  });
}

export function pr() {
  return {
    useThumbnail: Y.useContext(ur)
  };
}

export function mr() {
  return Y.useContext(dr);
}