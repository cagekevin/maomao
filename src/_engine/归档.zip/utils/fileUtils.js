import { Fr, Rr } from '../config/constants.js';

export function Kn(e, t = `mp4`) {
  try {
    let n = e.split(`?`)[0],
      r = n.substring(n.lastIndexOf(`/`) + 1);
    return r && r.includes(`.`) ? r : `clip_${Date.now()}.${t}`;
  } catch {
    return `clip_${Date.now()}.${t}`;
  }
}

export const vr = async (e, t = 200, n = .6) => new Promise((r, i) => {
  let a,
    o = false;
  e instanceof File || e instanceof Blob ? (a = URL.createObjectURL(e), o = true) : a = e;
  let s = new Image();
  s.crossOrigin = `anonymous`, s.onload = () => {
    o && URL.revokeObjectURL(a);
    let i = s.width,
      c = s.height;
    i > c ? i > t && (c = Math.round(c * t / i), i = t) : c > t && (i = Math.round(i * t / c), c = t);
    let l = document.createElement(`canvas`);
    l.width = i, l.height = c;
    let u = l.getContext(`2d`);
    if (!u) {
      r(typeof e == `string` ? e : ``);
      return;
    }
    u.drawImage(s, 0, 0, i, c), r(l.toDataURL(`image/jpeg`, n));
  }, s.onerror = () => {
    o && URL.revokeObjectURL(a), typeof e == `string` ? r(e) : i(Error(`Failed to load image for thumbnail`));
  }, s.src = a;
});

export const yr = async (e, t = 2048, n = .85) => new Promise((r, i) => {
  let a,
    o = false,
    s = `image/jpeg`;
  e instanceof File || e instanceof Blob ? (a = URL.createObjectURL(e), o = true, e.type === `image/png` ? s = `image/png` : e.type === `image/webp` && (s = `image/webp`)) : (a = e, a.startsWith(`data:image/png`) ? s = `image/png` : a.startsWith(`data:image/webp`) && (s = `image/webp`));
  let c = new Image();
  c.crossOrigin = `anonymous`, c.onload = () => {
    o && URL.revokeObjectURL(a);
    let e = c.width,
      i = c.height;
    (e > t || i > t) && (e > i ? (i = Math.round(i * t / e), e = t) : (e = Math.round(e * t / i), i = t));
    let l = document.createElement(`canvas`);
    l.width = e, l.height = i;
    let u = l.getContext(`2d`);
    if (!u) {
      r(a);
      return;
    }
    s === `image/jpeg` && (u.fillStyle = `#FFFFFF`, u.fillRect(0, 0, e, i)), u.drawImage(c, 0, 0, e, i), r(l.toDataURL(s, n));
  }, c.onerror = () => {
    o && URL.revokeObjectURL(a), typeof e == `string` ? r(e) : i(Error(`Failed to load image for resizing`));
  }, c.src = a;
});

export const br = async e => new Promise((t, n) => {
  let r = e instanceof File || e instanceof Blob ? URL.createObjectURL(e) : e,
    i = e instanceof File || e instanceof Blob,
    a = new Image();
  a.crossOrigin = `anonymous`, a.onload = () => {
    i && URL.revokeObjectURL(r), t({
      width: a.naturalWidth || a.width,
      height: a.naturalHeight || a.height
    });
  }, a.onerror = () => {
    i && URL.revokeObjectURL(r), n(Error(`Failed to load image for dimension detection`));
  }, a.src = r;
});

export const xr = async (e, t = 1e3, n = .85) => {
  let {
    width: r,
    height: i
  } = await br(e);
  if (r <= t && i <= t) return {
    blob: e,
    compressed: false
  };
  let a = await yr(e, t, n);
  return {
    blob: await (await fetch(a)).blob(),
    compressed: true
  };
};

export function Ir(e) {
  if (!Number.isFinite(e) || e <= 0) return Fr[0];
  for (let t of Fr) if (e <= t) return t;
  return null;
}

export function Lr(e, t, n) {
  if (!e) return e ?? ``;
  if (!e.includes(`/files/`) || e.startsWith(`data:`) || e.startsWith(`blob:`)) return e;
  if (t === null) return n === `video` ? Lr(e, Fr[Fr.length - 1], `video`) : e;
  let [r, i] = e.split(`?`);
  return `${r}${n === `video` ? `_frame1_resize_${t}.jpg` : `_resize_${t}.jpg`}${i ? `?` + i : ``}`;
}

export function zr(e) {
  if (!e || !e.includes(`/files/`) || e.startsWith(`data:`) || e.startsWith(`blob:`)) return null;
  let [t, n] = e.split(`?`);
  return `${t}${Rr}${n ? `?` + n : ``}`;
}

export function Br(e, t) {
  let n = zr(e);
  return n ? Lr(n, t, `image`) : null;
}

export function Vr(e) {
  if (!e) return null;
  let t = e.split(`?`)[0],
    n = t.indexOf(`/files/resources/`);
  if (n < 0) return null;
  let r = t.slice(n + 17),
    i = r.lastIndexOf(`/`);
  return i < 0 ? {
    subfolder: ``,
    filename: r
  } : {
    subfolder: r.slice(0, i),
    filename: r.slice(i + 1)
  };
}

export async function qr(e) {
  if (e instanceof File) {
    let t = e.name.includes(`.`) ? e.name.split(`.`).pop() : Jr(e.type);
    return {
      blob: e,
      suggestedName: e.name,
      ext: t
    };
  }
  if (e instanceof Blob) {
    let t = Jr(e.type);
    return {
      blob: e,
      suggestedName: `blob_${Date.now()}.${t}`,
      ext: t
    };
  }
  if (e.startsWith(`data:`)) {
    let t = Yr(e),
      n = Jr(t.type);
    return {
      blob: t,
      suggestedName: `data_${Date.now()}.${n}`,
      ext: n
    };
  }
  let t = await (await fetch(e)).blob(),
    n = Jr(t.type);
  return {
    blob: t,
    suggestedName: `remote_${Date.now()}.${n}`,
    ext: n
  };
}

export function Jr(e) {
  return e ? e.includes(`png`) ? `png` : e.includes(`jpeg`) || e.includes(`jpg`) ? `jpg` : e.includes(`webp`) ? `webp` : e.includes(`gif`) ? `gif` : e.includes(`mp4`) ? `mp4` : e.includes(`webm`) ? `webm` : e.includes(`flac`) ? `flac` : e.includes(`aac`) ? `aac` : e.includes(`ogg`) ? `ogg` : e.includes(`opus`) ? `opus` : e.includes(`mpeg`) ? `mp3` : e.includes(`m4a`) || e.includes(`mp4a`) ? `m4a` : e.includes(`wav`) ? `wav` : e.includes(`aiff`) ? `aiff` : e.includes(`plain`) ? `txt` : (e.split(`/`)[1] || ``).replace(/^x-/, ``) || `bin` : `bin`;
}

export function Yr(e) {
  let [t, n] = e.split(`,`),
    r = t.match(/data:([^;]+)/)?.[1] || `application/octet-stream`,
    i = t.includes(`;base64`) ? atob(n) : decodeURIComponent(n),
    a = new ArrayBuffer(i.length),
    o = new Uint8Array(a);
  for (let e = 0; e < i.length; e++) o[e] = i.charCodeAt(e);
  return new Blob([a], {
    type: r
  });
}

export function Qr(e) {
  return e.startsWith(`image/`) ? `img` : e.startsWith(`video/`) ? `vid` : e.startsWith(`audio/`) ? `aud` : `file`;
}

export function $r() {
  return Math.random().toString(36).slice(2, 8);
}