import { Wn, Hr } from '../config/constants.js';

export async function Gn(e) {
  if (!e.fileUrl && !e.localPath) return { ok: false, message: `没有可发送的素材` };
  try {
    let t = await fetch(`http://127.0.0.1:${Wn}/api/jianying/send`, {
      method: `POST`,
      headers: { "Content-Type": `application/json` },
      body: JSON.stringify({ fileUrl: e.fileUrl || ``, localPath: e.localPath || ``, fileName: e.fileName || `` })
    });
    let n = await t.json().catch(() => ({}));
    return t.ok && n.status === `ok` ? { ok: true, message: n.message || `已发送到剪映` } : { ok: false, message: n.error || `发送失败 (HTTP ${t.status})` };
  } catch (e) {
    let t = String(e?.message || e);
    return t.includes(`Failed to fetch`) || t.includes(`NetworkError`) ? { ok: false, message: `无法连接本地引擎，请确认引擎已启动` } : { ok: false, message: t };
  }
}

let Ur = null, Wr = 0;
export async function Kr() {
  let e = Date.now();
  if (Ur !== null && e - Wr < 3e3) return Ur;
  try {
    let e = new AbortController(),
      t = setTimeout(() => e.abort(), 1e3),
      n = await fetch(`${Hr}/api/status`, { signal: e.signal });
    if (clearTimeout(t), Ur = n.ok, n.ok) try {
      let e = await n.clone().json();
      typeof e?.ffmpeg == `boolean` && e.ffmpeg;
    } catch {}
  } catch {
    Ur = false;
  }
  return Wr = e, Ur;
}

export async function Xr(e, t = {}) {
  try {
    let n = await fetch(`${Hr}/api/files/upload`, {
      method: 'POST',
      body: e,
      ...t
    });
    return await n.json();
  } catch (error) {
    console.error('Upload failed', error);
    throw error;
  }
}

export async function Zr(e, t = {}) {
  try {
    let n = await fetch(e, {
      headers: {
        'Accept': 'application/json',
        ...t.headers
      },
      ...t
    });
    if (!n.ok) throw new Error(`HTTP error! status: ${n.status}`);
    return await n.json();
  } catch (error) {
    console.error('API Request failed', error);
    throw error;
  }
}