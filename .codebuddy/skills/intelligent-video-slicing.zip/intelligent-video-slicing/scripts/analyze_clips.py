"""分析切片质量脚本：统计每个视频的 clip 数量与时长，标记需要重切的"""
import subprocess
import json
import sys
from pathlib import Path

def get_duration(filepath: Path) -> float:
    """通过 ffprobe 获取媒体时长 (秒)"""
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", str(filepath)],
        capture_output=True, text=True,
        timeout=30
    )
    try:
        return float(json.loads(r.stdout)["format"]["duration"])
    except Exception:
        return 0.0

def main():
    if len(sys.argv) < 3:
        print("Usage: analyze_clips.py <output_dir> <input_dir>")
        sys.exit(1)

    out_dir = Path(sys.argv[1])
    inp_dir = Path(sys.argv[2])
    need_retry = []
    ok_count = 0
    skip_count = 0

    print(f"{'video':45} {'clips':>5} {'total':>7} {'avg':>7} {'src':>7}  flag")
    print("-" * 90)

    for d in sorted(out_dir.iterdir()):
        if not d.is_dir():
            continue
        clips = sorted(d.glob("*.mp4"))
        n = len(clips)
        if n == 0:
            continue

        total = sum(get_duration(c) for c in clips)
        avg = total / n if n else 0.0
        src = get_duration(inp_dir / (d.name + ".mp4"))

        flag = ""
        if n <= 1 or (avg > 8.0 and src > 10):
            flag = "UNDERCUT"
            need_retry.append((d.name, n, avg, src, "undercut"))
        elif avg < 2.0 and n > 2:
            flag = "OVERCUT"
            need_retry.append((d.name, n, avg, src, "overcut"))
        else:
            ok_count += 1

        print(f"{d.name:45} {n:5d} {total:7.1f} {avg:7.1f} {src:7.1f}  {flag}")

    print(f"\n合格: {ok_count}  需重切: {len(need_retry)}")
    return need_retry

if __name__ == "__main__":
    result = main()
    sys.exit(0 if not result else 1)
